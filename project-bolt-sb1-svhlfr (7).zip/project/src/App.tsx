import { useState } from 'react';
import { Package, Users, ShoppingCart } from 'lucide-react';
import Menu from './components/Menu';
import BackButton from './components/BackButton';
import ProductForm from './components/ProductForm';
import ProductList from './components/ProductList';
import CustomerForm from './components/CustomerForm';
import CustomerList from './components/CustomerList';
import SaleForm from './components/SaleForm';
import OrdersList from './components/OrdersList';
import Balance from './components/Balance';
import ProductionOrderSheet from './components/ProductionOrderSheet';
import Labels from './components/Labels';
import Uniatria from './components/Uniatria';
import PedidoSola from './components/PedidoSola';
import { useDatabase } from './hooks/useDatabase';

export default function App() {
  const [activeTab, setActiveTab] = useState('products');
  const [showMenu, setShowMenu] = useState(true);
  const {
    loading,
    products,
    customers,
    sales,
    orders,
    stockHistory,
    addProduct,
    updateProduct,
    addCustomer,
    addSale,
    addOrder,
    updateOrder,
    deleteOrder,
    addStockHistory,
  } = useDatabase();

  const handleAddProduct = (product: any) => {
    const newProduct = {
      ...product,
      id: crypto.randomUUID(),
      lastUpdated: new Date().toISOString(),
    };
    addProduct(newProduct);
  };

  const handleAddCustomer = (customer: any) => {
    const newCustomer = {
      ...customer,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
    };
    addCustomer(newCustomer);
  };

  const handleAddSale = (saleData: any) => {
    const sale = {
      ...saleData,
      id: crypto.randomUUID(),
      date: new Date().toISOString(),
      total: saleData.items.reduce((sum: number, item: any) => sum + (item.quantity * item.priceAtSale), 0),
    };
    
    addSale(sale);

    const order = {
      id: crypto.randomUUID(),
      customerId: sale.customerId,
      items: sale.items,
      total: sale.total,
      date: sale.date,
      status: 'pending',
      notes: sale.notes,
    };
    
    addOrder(order);
  };

  const handleUpdateStock = (productId: string, quantity: number, type: 'add' | 'remove') => {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    const updatedProduct = {
      ...product,
      quantity: type === 'add' ? product.quantity + quantity : product.quantity - quantity,
      lastUpdated: new Date().toISOString(),
    };

    updateProduct(updatedProduct);
  };

  const handleAddHistory = (history: any) => {
    const newHistory = {
      ...history,
      id: crypto.randomUUID(),
    };
    addStockHistory(newHistory);
  };

  const handleUpdateOrderStatus = (orderId: string, status: string) => {
    const order = orders.find(o => o.id === orderId);
    if (!order) return;

    const updatedOrder = {
      ...order,
      status,
    };

    updateOrder(updatedOrder);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-xl">Carregando...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {showMenu ? (
        <Menu activeTab={activeTab} onTabChange={(tab) => {
          setActiveTab(tab);
          setShowMenu(false);
        }} />
      ) : (
        <BackButton onClick={() => setShowMenu(true)} />
      )}
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-8">
          {!showMenu && (
            <>
              {activeTab === 'products' && (
                <>
                  <ProductForm onSubmit={handleAddProduct} />
                  <ProductList 
                    products={products}
                    stockHistory={stockHistory}
                    onUpdateStock={handleUpdateStock}
                    onAddHistory={handleAddHistory}
                  />
                </>
              )}
              
              {activeTab === 'customers' && (
                <>
                  <CustomerForm onSubmit={handleAddCustomer} />
                  <CustomerList customers={customers} />
                </>
              )}
              
              {activeTab === 'sales' && (
                <SaleForm
                  products={products}
                  customers={customers}
                  onSubmit={handleAddSale}
                />
              )}
              
              {activeTab === 'orders' && (
                <OrdersList
                  orders={orders}
                  customers={customers}
                  products={products}
                  onUpdateStatus={handleUpdateOrderStatus}
                  onDeleteOrder={deleteOrder}
                  onSelectOrder={() => {}}
                />
              )}
              
              {activeTab === 'balance' && (
                <Balance 
                  sales={sales.filter(sale => sale.status === 'completed')}
                  customers={customers}
                />
              )}
              
              {activeTab === 'orderSheet' && (
                <ProductionOrderSheet />
              )}

              {activeTab === 'labels' && (
                <Labels />
              )}

              {activeTab === 'uniatria' && (
                <Uniatria />
              )}

              {activeTab === 'pedidoSola' && (
                <PedidoSola />
              )}
            </>
          )}
        </div>
      </main>
    </div>
  );
}