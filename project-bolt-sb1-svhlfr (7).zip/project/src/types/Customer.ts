export interface Customer {
  id: string;
  name: string;
  phone: string;
  address: string;
  createdAt: string;
  lastPurchase?: string;
}

export type CustomerFormData = Omit<Customer, 'id' | 'createdAt' | 'lastPurchase'>;