export interface SaleItem {
  productId: string;
  quantity: number;
  priceAtSale: number;
}

export interface Sale {
  id: string;
  customerId: string;
  items: SaleItem[];
  total: number;
  date: string;
  status: 'completed' | 'pending' | 'cancelled';
  paymentMethod: 'credit' | 'debit' | 'cash' | 'transfer';
  notes?: string;
}

export type SaleFormData = Omit<Sale, 'id' | 'date' | 'total'>;