export interface OrderSheetRow {
  lining: string;
  sole: string;
  soleColor: string;
  character: string;
  sizes: { [key: string]: string };
}

export interface OrderSheet {
  id: string;
  orderNumber: string;
  client: string;
  category: string;
  orderDate: string;
  deliveryDate: string;
  rows: OrderSheetRow[];
  createdAt: string;
}