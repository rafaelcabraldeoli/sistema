export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  quantity: number;
  image: string;
  lastUpdated: string;
}

export interface StockHistory {
  id: string;
  productId: string;
  type: 'add' | 'remove';
  quantity: number;
  date: string;
  notes: string;
}

export type ProductFormData = Omit<Product, 'id' | 'image' | 'lastUpdated'>;