import { useEffect, useState } from 'react';
import { db } from '../services/db';
import type { Product } from '../types/Product';
import type { Customer } from '../types/Customer';
import type { Sale } from '../types/Sale';
import type { Order } from '../types/Order';
import type { StockHistory } from '../types/Product';

export function useDatabase() {
  const [products, setProducts] = useState<Product[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [stockHistory, setStockHistory] = useState<StockHistory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAllData();
    // Clean up old sales every hour
    const interval = setInterval(cleanupOldSales, 3600000);
    return () => clearInterval(interval);
  }, []);

  const cleanupOldSales = async () => {
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const oldSales = sales.filter(sale => 
      sale.status === 'completed' && 
      new Date(sale.date) < thirtyDaysAgo
    );

    for (const sale of oldSales) {
      await db.deleteSale(sale.id);
    }

    setSales(prev => prev.filter(sale => 
      !(sale.status === 'completed' && new Date(sale.date) < thirtyDaysAgo)
    ));
  };

  const loadAllData = async () => {
    try {
      const [
        productsData,
        customersData,
        salesData,
        ordersData,
        stockHistoryData
      ] = await Promise.all([
        db.getAllProducts(),
        db.getAllCustomers(),
        db.getAllSales(),
        db.getAllOrders(),
        db.getAllStockHistory()
      ]);

      setProducts(productsData);
      setCustomers(customersData);
      setSales(salesData);
      setOrders(ordersData);
      setStockHistory(stockHistoryData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const addProduct = async (product: Product) => {
    await db.addProduct(product);
    setProducts(prev => [...prev, product]);
  };

  const updateProduct = async (product: Product) => {
    await db.updateProduct(product);
    setProducts(prev => prev.map(p => p.id === product.id ? product : p));
  };

  const addCustomer = async (customer: Customer) => {
    await db.addCustomer(customer);
    setCustomers(prev => [...prev, customer]);
  };

  const updateCustomer = async (customer: Customer) => {
    await db.updateCustomer(customer);
    setCustomers(prev => prev.map(c => c.id === customer.id ? customer : c));
  };

  const addSale = async (sale: Sale) => {
    await db.addSale(sale);
    setSales(prev => [...prev, sale]);

    // Update customer's last purchase date
    const customer = customers.find(c => c.id === sale.customerId);
    if (customer) {
      const updatedCustomer = {
        ...customer,
        lastPurchase: sale.date
      };
      await updateCustomer(updatedCustomer);
    }
  };

  const updateSale = async (sale: Sale) => {
    await db.updateSale(sale);
    setSales(prev => prev.map(s => s.id === sale.id ? sale : s));
  };

  const deleteSale = async (saleId: string) => {
    const sale = sales.find(s => s.id === saleId);
    if (!sale || sale.status === 'completed') {
      throw new Error('Vendas confirmadas não podem ser excluídas');
    }
    await db.deleteSale(saleId);
    setSales(prev => prev.filter(s => s.id !== saleId));
  };

  const addOrder = async (order: Order) => {
    await db.addOrder(order);
    setOrders(prev => [...prev, order]);
  };

  const updateOrder = async (order: Order) => {
    await db.updateOrder(order);
    setOrders(prev => prev.map(o => o.id === order.id ? order : o));

    // If order is completed, update the corresponding sale
    if (order.status === 'completed') {
      const sale = sales.find(s => s.customerId === order.customerId && s.items.some(i => 
        order.items.some(oi => oi.productId === i.productId)
      ));
      if (sale) {
        const updatedSale = { ...sale, status: 'completed' as const };
        await updateSale(updatedSale);
      }
    }
  };

  const deleteOrder = async (orderId: string) => {
    const order = orders.find(o => o.id === orderId);
    if (!order) return;

    // Check if there's a completed sale associated with this order
    const relatedSale = sales.find(s => 
      s.status === 'completed' && 
      s.customerId === order.customerId &&
      s.items.some(i => order.items.some(oi => oi.productId === i.productId))
    );

    if (relatedSale) {
      throw new Error('Não é possível excluir um pedido com venda confirmada');
    }

    await db.deleteOrder(orderId);
    setOrders(prev => prev.filter(o => o.id !== orderId));
  };

  const addStockHistory = async (history: StockHistory) => {
    await db.addStockHistory(history);
    setStockHistory(prev => [...prev, history]);
  };

  return {
    loading,
    products,
    customers,
    sales,
    orders,
    stockHistory,
    addProduct,
    updateProduct,
    addCustomer,
    updateCustomer,
    addSale,
    updateSale,
    deleteSale,
    addOrder,
    updateOrder,
    deleteOrder,
    addStockHistory,
  };
}