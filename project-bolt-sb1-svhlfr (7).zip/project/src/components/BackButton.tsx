import React from 'react';
import { ArrowLeft } from 'lucide-react';

interface BackButtonProps {
  onClick: () => void;
}

export default function BackButton({ onClick }: BackButtonProps) {
  return (
    <button
      onClick={onClick}
      className="fixed top-4 left-4 p-2 text-gray-600 hover:text-gray-800 bg-white rounded-full shadow-lg hover:shadow-xl transition-all z-50"
      title="Voltar"
    >
      <ArrowLeft size={24} />
    </button>
  );
}