import React, { useState, useEffect } from 'react';
import { Printer, List, X, ArrowLeft } from 'lucide-react';
import type { OrderSheet } from '../types/OrderSheet';
import { db } from '../services/db';

export default function Uniatria() {
  const [savedSheets, setSavedSheets] = useState<OrderSheet[]>([]);
  const [showSavedSheets, setShowSavedSheets] = useState(true);
  const [selectedSheet, setSelectedSheet] = useState<OrderSheet | null>(null);
  const [labels, setLabels] = useState<Array<{
    character: string;
    size: string;
    category: string;
  }>>([]);

  useEffect(() => {
    loadSavedSheets();
  }, []);

  const loadSavedSheets = async () => {
    const sheets = await db.getAllOrderSheets();
    setSavedSheets(sheets.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
  };

  const generateLabels = (sheet: OrderSheet) => {
    const newLabels: Array<{
      character: string;
      size: string;
      category: string;
    }> = [];

    sheet.rows.forEach(row => {
      if (!row.character) return;

      Object.entries(row.sizes).forEach(([size, quantity]) => {
        const qty = parseInt(quantity);
        if (qty > 0) {
          for (let i = 0; i < qty * 2; i++) {
            newLabels.push({
              character: row.character.toUpperCase(),
              size,
              category: row.sole,
            });
          }
        }
      });
    });

    setLabels(newLabels);
    setSelectedSheet(sheet);
    setShowSavedSheets(false);
  };

  const handlePrint = () => {
    window.print();
  };

  const labelRows = labels.reduce<Array<typeof labels>>((rows, label, index) => {
    if (index % 3 === 0) {
      rows.push([label]);
    } else {
      rows[rows.length - 1].push(label);
    }
    return rows;
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">Etiquetas Unitárias</h2>
        <div className="flex gap-4">
          <button
            onClick={() => setShowSavedSheets(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 no-print"
          >
            <List size={20} />
            Selecionar Ficha
          </button>
          {labels.length > 0 && (
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 no-print"
            >
              <Printer size={20} />
              Imprimir Etiquetas ({labels.length})
            </button>
          )}
        </div>
      </div>

      {showSavedSheets && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold">Selecione uma Ficha</h3>
              <div className="flex gap-2">
                <button
                  onClick={() => setShowSavedSheets(false)}
                  className="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700"
                >
                  <ArrowLeft size={20} />
                  Voltar
                </button>
                <button
                  onClick={() => setShowSavedSheets(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X size={24} />
                </button>
              </div>
            </div>
            <div className="space-y-4">
              {savedSheets.map((sheet) => (
                <div key={sheet.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-semibold">{sheet.client}</p>
                    <p className="text-sm text-gray-500">
                      Pedido #{sheet.orderNumber} • {new Date(sheet.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <button
                    onClick={() => generateLabels(sheet)}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                  >
                    Gerar Etiquetas
                  </button>
                </div>
              ))}
              {savedSheets.length === 0 && (
                <p className="text-center text-gray-500">Nenhuma ficha salva</p>
              )}
            </div>
          </div>
        </div>
      )}

      <div id="print-labels" className="space-y-[0.5mm]">
        {labelRows.map((row, rowIndex) => (
          <div key={rowIndex} className="label-row">
            {row.map((label, index) => (
              <div key={index} className="label">
                <div className="content">
                  <div className="character">{label.character}</div>
                  <div className="info-row">
                    <span className="size">{label.size}</span>
                    <span className="category">{label.category}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>

      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #print-labels, #print-labels * {
            visibility: visible;
          }
          #print-labels {
            position: absolute;
            left: 0;
            top: 0;
            width: 110mm;
            margin: 0;
            padding: 0;
          }
          .label-row {
            break-inside: avoid;
            page-break-after: auto;
          }
          @page {
            size: 110mm auto;
            margin: 0;
          }
        }

        .label-row {
          width: 110mm;
          height: 21mm;
          display: flex;
          justify-content: space-between;
          padding: 0;
          margin: 0;
          background: white;
        }

        .label {
          width: 32mm;
          height: 21mm;
          background: white;
          display: flex;
          align-items: center;
          justify-content: center;
          margin: 0;
          padding: 0;
        }

        .content {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          width: 100%;
          height: 100%;
          padding: 1mm;
        }

        .character {
          font-family: 'Arial Black', Arial, sans-serif;
          font-size: 10pt;
          font-weight: 900;
          line-height: 1;
          margin-bottom: 1mm;
        }

        .info-row {
          display: flex;
          align-items: center;
          gap: 2mm;
          font-family: 'Arial Black', Arial, sans-serif;
          font-weight: 900;
          white-space: nowrap;
        }

        .size {
          font-size: 18pt;
        }

        .category {
          font-size: 8pt;
        }

        @media screen {
          #print-labels {
            width: 110mm;
            margin: 0 auto;
            background: #f0f0f0;
            padding: 5mm;
          }
        }
      `}</style>
    </div>
  );
}