{/* Previous imports remain the same */}

export default function StockControl({ product, onUpdateStock, onAddHistory }: StockControlProps) {
  // ... state declarations remain the same

  return (
    <div className="p-4 space-y-4">
      {isLowStock && (
        <div className="flex items-center gap-2 text-amber-600 bg-amber-50 p-2 rounded-md">
          <AlertTriangle size={20} />
          <span className="text-sm">Alerta de estoque baixo!</span>
        </div>
      )}
      
      <div className="flex gap-4">
        <input
          type="number"
          min="1"
          value={quantity}
          onChange={(e) => setQuantity(Math.max(0, parseInt(e.target.value) || 0))}
          className="w-24 px-2 py-1 border rounded-md"
          placeholder="Qtd"
        />
        <input
          type="text"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          className="flex-1 px-2 py-1 border rounded-md"
          placeholder="Observações (opcional)"
        />
      </div>
      
      <div className="flex gap-2">
        <button
          onClick={() => handleStockChange('add')}
          className="flex items-center gap-1 px-3 py-1 bg-green-600 text-white rounded-md hover:bg-green-700"
        >
          <Plus size={16} />
          Adicionar
        </button>
        <button
          onClick={() => handleStockChange('remove')}
          className="flex items-center gap-1 px-3 py-1 bg-red-600 text-white rounded-md hover:bg-red-700"
        >
          <Minus size={16} />
          Remover
        </button>
      </div>
    </div>
  );
}