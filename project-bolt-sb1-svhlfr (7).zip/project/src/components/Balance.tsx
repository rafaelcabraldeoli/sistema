import React, { useMemo } from 'react';
import { Calendar, TrendingUp, DollarSign, User } from 'lucide-react';
import type { Sale } from '../types/Sale';
import type { Customer } from '../types/Customer';
import { formatCurrency } from '../utils/formatters';

interface BalanceProps {
  sales: Sale[];
  customers: Customer[];
}

export default function Balance({ sales, customers }: BalanceProps) {
  const revenueData = useMemo(() => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const weekStart = new Date(today);
    weekStart.setDate(today.getDate() - today.getDay());
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    const completedSales = sales.filter(sale => sale.status === 'completed');

    return {
      daily: completedSales
        .filter(sale => new Date(sale.date) >= today)
        .reduce((sum, sale) => sum + sale.total, 0),
      weekly: completedSales
        .filter(sale => new Date(sale.date) >= weekStart)
        .reduce((sum, sale) => sum + sale.total, 0),
      monthly: completedSales
        .filter(sale => new Date(sale.date) >= monthStart)
        .reduce((sum, sale) => sum + sale.total, 0),
    };
  }, [sales]);

  const getCustomerName = (customerId: string) => {
    return customers.find(c => c.id === customerId)?.name || 'Cliente não encontrado';
  };

  const getPaymentMethodText = (method: string) => {
    const methodMap: Record<string, string> = {
      'cash': 'Dinheiro',
      'credit': 'Cartão de Crédito',
      'debit': 'Cartão de Débito',
      'transfer': 'Transferência'
    };
    return methodMap[method] || method;
  };

  const revenueCards = [
    {
      title: 'Faturamento do Dia',
      value: revenueData.daily,
      icon: Calendar,
      color: 'bg-blue-500',
      period: new Date().toLocaleDateString(),
    },
    {
      title: 'Faturamento da Semana',
      value: revenueData.weekly,
      icon: TrendingUp,
      color: 'bg-green-500',
      period: 'Semana Atual',
    },
    {
      title: 'Faturamento do Mês',
      value: revenueData.monthly,
      icon: DollarSign,
      color: 'bg-purple-500',
      period: new Intl.DateTimeFormat('pt-BR', { month: 'long', year: 'numeric' }).format(new Date()),
    },
  ];

  return (
    <div className="space-y-8">
      <h2 className="text-2xl font-bold text-gray-800">Balanço Financeiro</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {revenueCards.map((card, index) => {
          const Icon = card.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-800">{card.title}</h3>
                  <div className={`p-3 rounded-lg ${card.color}`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <p className="text-3xl font-bold text-gray-900">
                    {formatCurrency(card.value)}
                  </p>
                  <p className="text-sm text-gray-500">{card.period}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-xl font-semibold text-gray-800 mb-4">Histórico de Vendas Confirmadas</h3>
        <div className="space-y-4">
          {sales
            .filter(sale => sale.status === 'completed')
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
            .map(sale => (
              <div key={sale.id} className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <User size={16} className="text-blue-500" />
                    <span className="font-medium">{getCustomerName(sale.customerId)}</span>
                  </div>
                  <p className="text-sm text-gray-500">
                    Venda #{sale.id.slice(0, 8)} • {new Date(sale.date).toLocaleString()}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-green-600">{formatCurrency(sale.total)}</p>
                  <p className="text-sm text-gray-500">{getPaymentMethodText(sale.paymentMethod)}</p>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}