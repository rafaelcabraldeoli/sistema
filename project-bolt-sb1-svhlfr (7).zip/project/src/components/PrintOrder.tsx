import React from 'react';
import type { Order } from '../types/Order';
import type { Customer } from '../types/Customer';
import type { Product } from '../types/Product';
import { formatCurrency } from '../utils/formatters';

interface PrintOrderProps {
  order: Order;
  customer: Customer;
  products: Product[];
}

export default function PrintOrder({ order, customer, products }: PrintOrderProps) {
  const getProduct = (productId: string): Product | undefined => {
    return products.find(p => p.id === productId);
  };

  const getProductName = (productId: string): string => {
    const product = getProduct(productId);
    return product?.name || 'Produto não encontrado';
  };

  React.useEffect(() => {
    const style = document.createElement('style');
    style.innerHTML = `
      @media print {
        body * {
          visibility: hidden;
        }
        #print-order, #print-order * {
          visibility: visible;
        }
        #print-order {
          position: absolute;
          left: 0;
          top: 0;
          width: 100%;
        }
        @page {
          size: A4;
          margin: 20mm;
        }
      }
    `;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);

  return (
    <div id="print-order" className="bg-white p-8 max-w-2xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-2xl font-bold">Pedido de Produção</h1>
        <p className="text-gray-600">Pedido #{order.id.slice(0, 8)}</p>
      </div>

      <div className="grid grid-cols-2 gap-8 mb-8">
        <div>
          <h2 className="text-lg font-semibold mb-2">Dados do Cliente</h2>
          <div className="space-y-1">
            <p>{customer.name}</p>
            <p>{customer.phone}</p>
            <p className="whitespace-pre-line">{customer.address}</p>
          </div>
        </div>
        <div>
          <h2 className="text-lg font-semibold mb-2">Detalhes do Pedido</h2>
          <div className="space-y-1">
            <p>Data: {new Date(order.date).toLocaleDateString()}</p>
            {order.notes && <p>Observações: {order.notes}</p>}
          </div>
        </div>
      </div>

      <table className="w-full mb-8">
        <thead>
          <tr className="border-b-2 border-gray-200">
            <th className="text-left py-2">Item</th>
            <th className="text-right py-2">Quantidade</th>
            <th className="text-right py-2">Preço Unit.</th>
            <th className="text-right py-2">Total</th>
          </tr>
        </thead>
        <tbody>
          {order.items.map((item, index) => {
            const product = getProduct(item.productId);
            return (
              <tr key={index} className="border-b border-gray-100">
                <td className="py-2">{getProductName(item.productId)}</td>
                <td className="text-right py-2">{item.quantity}</td>
                <td className="text-right py-2">{formatCurrency(product?.price || 0)}</td>
                <td className="text-right py-2">
                  {formatCurrency((product?.price || 0) * item.quantity)}
                </td>
              </tr>
            );
          })}
        </tbody>
        <tfoot>
          <tr className="font-bold">
            <td colSpan={3} className="text-right py-2">Total:</td>
            <td className="text-right py-2">{formatCurrency(order.total)}</td>
          </tr>
        </tfoot>
      </table>

      <div className="text-center text-sm text-gray-500 mt-16">
        <p>Obrigado pela preferência!</p>
      </div>
    </div>
  );
}