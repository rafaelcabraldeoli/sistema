import React, { useState } from 'react';
import { ShoppingCart, Plus, Trash2 } from 'lucide-react';
import type { Product } from '../types/Product';
import type { Customer } from '../types/Customer';

interface SaleFormProps {
  products: Product[];
  customers: Customer[];
  onSubmit: (sale: {
    customerId: string;
    items: Array<{ productId: string; quantity: number; priceAtSale: number }>;
    status: 'completed' | 'pending' | 'cancelled';
    paymentMethod: 'credit' | 'debit' | 'cash' | 'transfer';
    notes?: string;
  }) => void;
}

export default function SaleForm({ products, customers, onSubmit }: SaleFormProps) {
  const [formData, setFormData] = useState({
    customerId: '',
    items: [] as Array<{ productId: string; quantity: number; priceAtSale: number }>,
    status: 'completed' as const,
    paymentMethod: 'cash' as const,
    notes: '',
  });

  const [selectedProduct, setSelectedProduct] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);

  const handleAddItem = () => {
    const product = products.find(p => p.id === selectedProduct);
    if (!product || quantity <= 0) return;

    if (product.quantity < quantity) {
      alert('Estoque insuficiente');
      return;
    }

    const newItem = {
      productId: product.id,
      quantity,
      priceAtSale: product.price,
    };

    setFormData(prev => ({
      ...prev,
      items: [...prev.items, newItem],
    }));

    setSelectedProduct('');
    setQuantity(1);
  };

  const removeItem = (index: number) => {
    setFormData(prev => ({
      ...prev,
      items: prev.items.filter((_, i) => i !== index),
    }));
  };

  const calculateTotal = () => {
    return formData.items.reduce((total, item) => {
      return total + (item.quantity * item.priceAtSale);
    }, 0);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.items.length === 0) {
      alert('Adicione pelo menos um item');
      return;
    }

    onSubmit(formData);
    
    setFormData({
      customerId: '',
      items: [],
      status: 'completed',
      paymentMethod: 'cash',
      notes: '',
    });
  };

  const getProductName = (productId: string) => {
    return products.find(p => p.id === productId)?.name || 'Produto Desconhecido';
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 bg-white p-8 rounded-xl shadow-lg max-w-2xl mx-auto">
      <div className="space-y-4">
        <h2 className="text-2xl font-bold text-gray-800">Nova Venda</h2>

        <div>
          <label className="block text-sm font-medium text-gray-700">Cliente</label>
          <select
            required
            value={formData.customerId}
            onChange={(e) => setFormData(prev => ({ ...prev, customerId: e.target.value }))}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm p-2 border"
          >
            <option value="">Selecione um cliente</option>
            {customers.map(customer => (
              <option key={customer.id} value={customer.id}>
                {customer.name}
              </option>
            ))}
          </select>
        </div>

        <div className="border-t pt-4">
          <h3 className="text-lg font-medium text-gray-800 mb-4">Adicionar Itens</h3>
          
          <div className="flex gap-2 mb-4">
            <select
              value={selectedProduct}
              onChange={(e) => setSelectedProduct(e.target.value)}
              className="flex-1 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm p-2 border"
            >
              <option value="">Selecione um produto</option>
              {products
                .filter(p => p.quantity > 0)
                .map(product => (
                  <option key={product.id} value={product.id}>
                    {product.name} (R$ {product.price.toFixed(2)} - Estoque: {product.quantity})
                  </option>
                ))}
            </select>
            
            <input
              type="number"
              min="1"
              value={quantity}
              onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
              className="w-24 rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm p-2 border"
            />
            
            <button
              type="button"
              onClick={handleAddItem}
              className="px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              <Plus size={20} />
            </button>
          </div>

          {formData.items.length > 0 && (
            <div className="space-y-2">
              {formData.items.map((item, index) => (
                <div key={index} className="flex items-center justify-between bg-gray-50 p-3 rounded-md">
                  <div>
                    <span className="font-medium">{getProductName(item.productId)}</span>
                    <div className="text-sm text-gray-500">
                      {item.quantity} x R$ {item.priceAtSale.toFixed(2)} = R$ {(item.quantity * item.priceAtSale).toFixed(2)}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => removeItem(index)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 size={20} />
                  </button>
                </div>
              ))}
              
              <div className="text-right font-bold text-lg pt-2">
                Total: R$ {calculateTotal().toFixed(2)}
              </div>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Forma de Pagamento</label>
            <select
              required
              value={formData.paymentMethod}
              onChange={(e) => setFormData(prev => ({ ...prev, paymentMethod: e.target.value as any }))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm p-2 border"
            >
              <option value="cash">Dinheiro</option>
              <option value="credit">Cartão de Crédito</option>
              <option value="debit">Cartão de Débito</option>
              <option value="transfer">Transferência</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Status</label>
            <select
              required
              value={formData.status}
              onChange={(e) => setFormData(prev => ({ ...prev, status: e.target.value as any }))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm p-2 border"
            >
              <option value="completed">Concluído</option>
              <option value="pending">Pendente</option>
              <option value="cancelled">Cancelado</option>
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Observações (Opcional)</label>
          <textarea
            value={formData.notes}
            onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
            rows={3}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm p-2 border"
            placeholder="Adicione observações..."
          />
        </div>

        <button
          type="submit"
          className="w-full flex justify-center items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors"
        >
          <ShoppingCart size={20} />
          Finalizar Venda
        </button>
      </div>
    </form>
  );
}