import React, { useState, useEffect } from 'react';
import { Printer, Plus, Trash2, Save, List, X, Settings, FileText } from 'lucide-react';
import type { OrderSheet } from '../types/OrderSheet';
import { db } from '../services/db';

interface OptionsModalProps {
  title: string;
  options: string[];
  onAdd: (option: string) => void;
  onRemove: (option: string) => void;
  onClose: () => void;
}

const SIZE_RANGES = ['20/21', '22/23', '24/25', '26/27', '28/29', '30/31', '32/33'];
const CATEGORIES = ['3LED NEW', '3LED CADARÇO', '3LED MEIA', 'KIDS', '6LED CADARÇO', '6LED MEIA', 'BOTA', 'LED CADARÇO', 'LED MEIA', 'CHINELOS'];

interface OrderRow {
  lining: string;
  sole: string;
  soleColor: string;
  character: string;
  sizes: { [key: string]: string };
}

const EMPTY_ROW: OrderRow = {
  lining: '',
  sole: '',
  soleColor: '',
  character: '',
  sizes: SIZE_RANGES.reduce((acc, size) => ({ ...acc, [size]: '' }), {})
};

const generateOrderNumber = () => {
  return `PED${new Date().getTime().toString().slice(-6)}`;
};

const EMPTY_SHEET = {
  orderNumber: generateOrderNumber(),
  client: '',
  category: '',
  orderDate: new Date().toISOString().split('T')[0],
  deliveryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
  rows: [{ ...EMPTY_ROW }]
};

function OptionsModal({ title, options, onAdd, onRemove, onClose }: OptionsModalProps) {
  const [newOption, setNewOption] = useState('');

  const handleAdd = () => {
    if (newOption.trim()) {
      onAdd(newOption.trim().toUpperCase());
      setNewOption('');
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-bold">{title}</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>
        </div>
        
        <div className="flex gap-2 mb-4">
          <input
            type="text"
            value={newOption}
            onChange={(e) => setNewOption(e.target.value)}
            className="flex-1 px-3 py-2 border rounded"
            placeholder="Nova opção"
          />
          <button
            onClick={handleAdd}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            <Plus size={20} />
          </button>
        </div>

        <div className="space-y-2 max-h-96 overflow-y-auto">
          {options.map((option) => (
            <div key={option} className="flex justify-between items-center p-2 bg-gray-50 rounded">
              <span>{option}</span>
              <button
                onClick={() => onRemove(option)}
                className="text-red-600 hover:text-red-800"
              >
                <Trash2 size={20} />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function ProductionOrderSheet() {
  const [sheets, setSheets] = useState<Array<typeof EMPTY_SHEET>>(Array(6).fill({ ...EMPTY_SHEET }));
  const [syncData, setSyncData] = useState(true);
  const [masterSheet, setMasterSheet] = useState({ ...EMPTY_SHEET });
  const [savedSheets, setSavedSheets] = useState<OrderSheet[]>([]);
  const [showSavedSheets, setShowSavedSheets] = useState(false);
  const [showOptionsModal, setShowOptionsModal] = useState<'lining' | 'sole' | 'soleColor' | null>(null);
  
  const [linings, setLinings] = useState(['VR', 'AZ', 'PT', 'VD', 'PK', 'RSBB', 'PKCH', 'AZBB', 'LILÁS']);
  const [soles, setSoles] = useState(['3LED', 'KIDS', 'LED']);
  const [soleColors, setSoleColors] = useState(['BRANCO', 'PRETO', 'PINK', 'ROYAL', 'VERMELHO', 'ROSA', 'VERDE', 'LILASBB', 'AZULBB', 'VERDE AGUA', 'LILÁS']);

  useEffect(() => {
    loadSavedSheets();
  }, []);

  const loadSavedSheets = async () => {
    const sheets = await db.getAllOrderSheets();
    setSavedSheets(sheets.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
  };

  const handleNewSheet = () => {
    const newSheet = {
      orderNumber: generateOrderNumber(),
      client: '',
      category: '',
      orderDate: new Date().toISOString().split('T')[0],
      deliveryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      rows: [{ ...EMPTY_ROW }]
    };
    
    setMasterSheet(newSheet);
    setSheets(Array(6).fill({ ...newSheet }));
  };

  const handleSave = async () => {
    const sheetsToSave = syncData ? [masterSheet] : sheets;
    
    for (const sheet of sheetsToSave) {
      if (!sheet.client.trim()) {
        alert('Por favor, preencha o nome do cliente antes de salvar.');
        return;
      }

      const orderSheet: OrderSheet = {
        id: crypto.randomUUID(),
        ...sheet,
        createdAt: new Date().toISOString()
      };

      await db.addOrderSheet(orderSheet);
    }

    await loadSavedSheets();
    alert('Ficha(s) salva(s) com sucesso!');
  };

  const handleLoadSheet = (sheet: OrderSheet) => {
    setMasterSheet({
      orderNumber: sheet.orderNumber,
      client: sheet.client,
      category: sheet.category,
      orderDate: sheet.orderDate,
      deliveryDate: sheet.deliveryDate,
      rows: sheet.rows
    });
    setShowSavedSheets(false);
  };

  const handleDeleteSheet = async (id: string) => {
    if (window.confirm('Tem certeza que deseja excluir esta ficha?')) {
      await db.deleteOrderSheet(id);
      await loadSavedSheets();
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleInputChange = (sheetIndex: number, field: string, value: string) => {
    if (field === 'orderNumber') return;

    if (syncData) {
      setMasterSheet(prev => ({
        ...prev,
        [field]: value
      }));
    } else {
      setSheets(prev => {
        const newSheets = [...prev];
        newSheets[sheetIndex] = {
          ...newSheets[sheetIndex],
          [field]: value
        };
        return newSheets;
      });
    }
  };

  const handleRowChange = (sheetIndex: number, rowIndex: number, field: string, value: string) => {
    if (syncData) {
      setMasterSheet(prev => {
        const newRows = [...prev.rows];
        if (field.includes('sizes.')) {
          const size = field.split('.')[1];
          newRows[rowIndex] = {
            ...newRows[rowIndex],
            sizes: { ...newRows[rowIndex].sizes, [size]: value }
          };
        } else {
          newRows[rowIndex] = {
            ...newRows[rowIndex],
            [field]: value
          };
        }
        return { ...prev, rows: newRows };
      });
    } else {
      setSheets(prev => {
        const newSheets = [...prev];
        const newRows = [...newSheets[sheetIndex].rows];
        if (field.includes('sizes.')) {
          const size = field.split('.')[1];
          newRows[rowIndex] = {
            ...newRows[rowIndex],
            sizes: { ...newRows[rowIndex].sizes, [size]: value }
          };
        } else {
          newRows[rowIndex] = {
            ...newRows[rowIndex],
            [field]: value
          };
        }
        newSheets[sheetIndex] = { ...newSheets[sheetIndex], rows: newRows };
        return newSheets;
      });
    }
  };

  const addRow = (sheetIndex: number) => {
    if (syncData) {
      setMasterSheet(prev => ({
        ...prev,
        rows: [...prev.rows, { ...EMPTY_ROW }]
      }));
    } else {
      setSheets(prev => {
        const newSheets = [...prev];
        newSheets[sheetIndex] = {
          ...newSheets[sheetIndex],
          rows: [...newSheets[sheetIndex].rows, { ...EMPTY_ROW }]
        };
        return newSheets;
      });
    }
  };

  const removeRow = (sheetIndex: number, rowIndex: number) => {
    if (syncData) {
      setMasterSheet(prev => ({
        ...prev,
        rows: prev.rows.filter((_, idx) => idx !== rowIndex)
      }));
    } else {
      setSheets(prev => {
        const newSheets = [...prev];
        newSheets[sheetIndex] = {
          ...newSheets[sheetIndex],
          rows: newSheets[sheetIndex].rows.filter((_, idx) => idx !== rowIndex)
        };
        return newSheets;
      });
    }
  };

  const calculateRowTotal = (sizes: { [key: string]: string }): number => {
    return Object.values(sizes).reduce((sum, value) => sum + (parseInt(value) || 0), 0);
  };

  const calculateSheetTotal = (rows: OrderRow[]): number => {
    return rows.reduce((sum, row) => sum + calculateRowTotal(row.sizes), 0);
  };

  const handleAddOption = (type: 'lining' | 'sole' | 'soleColor', option: string) => {
    switch (type) {
      case 'lining':
        setLinings(prev => [...prev, option]);
        break;
      case 'sole':
        setSoles(prev => [...prev, option]);
        break;
      case 'soleColor':
        setSoleColors(prev => [...prev, option]);
        break;
    }
  };

  const handleRemoveOption = (type: 'lining' | 'sole' | 'soleColor', option: string) => {
    switch (type) {
      case 'lining':
        setLinings(prev => prev.filter(o => o !== option));
        break;
      case 'sole':
        setSoles(prev => prev.filter(o => o !== option));
        break;
      case 'soleColor':
        setSoleColors(prev => prev.filter(o => o !== option));
        break;
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">Ficha de Pedido</h2>
        <div className="flex items-center gap-4">
          <button
            onClick={handleNewSheet}
            className="flex items-center gap-2 px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700 no-print"
          >
            <FileText size={20} />
            Nova Ficha
          </button>
          <div className="flex gap-2">
            <button
              onClick={() => setShowOptionsModal('lining')}
              className="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 no-print"
              title="Gerenciar opções de forro"
            >
              <Settings size={20} />
              Forros
            </button>
            <button
              onClick={() => setShowOptionsModal('sole')}
              className="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 no-print"
              title="Gerenciar opções de sola"
            >
              <Settings size={20} />
              Solas
            </button>
            <button
              onClick={() => setShowOptionsModal('soleColor')}
              className="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700 no-print"
              title="Gerenciar cores de sola"
            >
              <Settings size={20} />
              Cores
            </button>
          </div>
          <label className="flex items-center gap-2 text-sm no-print">
            <input
              type="checkbox"
              checked={syncData}
              onChange={(e) => setSyncData(e.target.checked)}
              className="rounded border-gray-300"
            />
            Sincronizar dados entre fichas
          </label>
          <button
            onClick={() => setShowSavedSheets(true)}
            className="flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 no-print"
          >
            <List size={20} />
            Fichas Salvas
          </button>
          <button
            onClick={handleSave}
            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 no-print"
          >
            <Save size={20} />
            Salvar
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 no-print"
          >
            <Printer size={20} />
            Imprimir
          </button>
        </div>
      </div>

      {showOptionsModal && (
        <OptionsModal
          title={
            showOptionsModal === 'lining' ? 'Gerenciar Forros' :
            showOptionsModal === 'sole' ? 'Gerenciar Solas' :
            'Gerenciar Cores de Sola'
          }
          options={
            showOptionsModal === 'lining' ? linings :
            showOptionsModal === 'sole' ? soles :
            soleColors
          }
          onAdd={(option) => handleAddOption(showOptionsModal, option)}
          onRemove={(option) => handleRemoveOption(showOptionsModal, option)}
          onClose={() => setShowOptionsModal(null)}
        />
      )}

      {showSavedSheets && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 no-print">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold">Fichas Salvas</h3>
              <button
                onClick={() => setShowSavedSheets(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X size={24} />
              </button>
            </div>
            <div className="space-y-4">
              {savedSheets.map((sheet) => (
                <div key={sheet.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-semibold">{sheet.client}</p>
                    <p className="text-sm text-gray-500">
                      Pedido #{sheet.orderNumber} • {new Date(sheet.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleLoadSheet(sheet)}
                      className="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700"
                    >
                      Carregar
                    </button>
                    <button
                      onClick={() => handleDeleteSheet(sheet.id)}
                      className="px-3 py-1 bg-red-600 text-white rounded hover:bg-red-700"
                    >
                      Excluir
                    </button>
                  </div>
                </div>
              ))}
              {savedSheets.length === 0 && (
                <p className="text-center text-gray-500">Nenhuma ficha salva</p>
              )}
            </div>
          </div>
        </div>
      )}

      <div id="print-order-sheet" className="bg-white p-4">
        {[0, 1].map((pageIndex) => (
          <div key={`page-${pageIndex}`} className="page">
            {[0, 1, 2].map((sheetIndex) => {
              const currentIndex = pageIndex * 3 + sheetIndex;
              const sheet = syncData ? masterSheet : sheets[currentIndex];
              return (
                <div key={`sheet-${currentIndex}`} className="order-sheet border border-gray-800">
                  <div className="grid grid-cols-12 gap-0.5 px-1 py-0.5">
                    <div className="col-span-2">
                      <label className="text-[7pt]">Nº Pedido:</label>
                      <input
                        type="text"
                        value={sheet.orderNumber}
                        readOnly
                        className="w-full border px-0.5 text-[9px] bg-gray-50"
                      />
                    </div>
                    <div className="col-span-4">
                      <label className="text-[7pt]">Cliente:</label>
                      <input
                        type="text"
                        value={sheet.client}
                        onChange={(e) => handleInputChange(currentIndex, 'client', e.target.value)}
                        className="w-full border px-0.5 text-[9px]"
                      />
                    </div>
                    <div className="col-span-2">
                      <label className="text-[7pt]">Categoria:</label>
                      <select
                        value={sheet.category}
                        onChange={(e) => handleInputChange(currentIndex, 'category', e.target.value)}
                        className="w-full border px-0.5 text-[9px]"
                      >
                        <option value="">Selecione</option>
                        {CATEGORIES.map((cat) => (
                          <option key={cat} value={cat}>{cat}</option>
                        ))}
                      </select>
                    </div>
                    <div className="col-span-2">
                      <label className="text-[7pt]">Data Pedido:</label>
                      <input
                        type="date"
                        value={sheet.orderDate}
                        onChange={(e) => handleInputChange(currentIndex, 'orderDate', e.target.value)}
                        className="w-full border px-0.5 text-[9px]"
                      />
                    </div>
                    <div className="col-span-2">
                      <label className="text-[7pt]">Previsão:</label>
                      <input
                        type="date"
                        value={sheet.deliveryDate}
                        onChange={(e) => handleInputChange(currentIndex, 'deliveryDate', e.target.value)}
                        className="w-full border px-0.5 text-[9px]"
                      />
                    </div>
                  </div>

                  <table className="w-full border-collapse text-[9px]">
                    <thead>
                      <tr className="h-4">
                        <th className="border w-14 text-[7pt]">FORRO</th>
                        <th className="border w-14 text-[7pt]">SOLA</th>
                        <th className="border w-14 text-[7pt]">COR SOLA</th>
                        <th className="border text-[7pt]">PERSONAGEM</th>
                        {SIZE_RANGES.map((size) => (
                          <th key={size} className="border w-8 text-[7pt]">{size}</th>
                        ))}
                        <th className="border w-10 text-[7pt]">PARES</th>
                        <th className="border w-4 no-print"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {sheet.rows.map((row, rowIndex) => (
                        <tr key={rowIndex} className="h-5">
                          <td className="border">
                            <select
                              value={row.lining}
                              onChange={(e) => handleRowChange(currentIndex, rowIndex, 'lining', e.target.value)}
                              className="w-full text-[9px]"
                            >
                              <option value="">-</option>
                              {linings.map((lining) => (
                                <option key={lining} value={lining}>{lining}</option>
                              ))}
                            </select>
                          </td>
                          <td className="border">
                            <select
                              value={row.sole}
                              onChange={(e) => handleRowChange(currentIndex, rowIndex, 'sole', e.target.value)}
                              className="w-full text-[9px]"
                            >
                              <option value="">-</option>
                              {soles.map((sole) => (
                                <option key={sole} value={sole}>{sole}</option>
                              ))}
                            </select>
                          </td>
                          <td className="border">
                            <select
                              value={row.soleColor}
                              onChange={(e) => handleRowChange(currentIndex, rowIndex, 'soleColor', e.target.value)}
                              className="w-full text-[9px]"
                            >
                              <option value="">-</option>
                              {soleColors.map((color) => (
                                <option key={color} value={color}>{color}</option>
                              ))}
                            </select>
                          </td>
                          <td className="border">
                            <input
                              type="text"
                              value={row.character}
                              onChange={(e) => handleRowChange(currentIndex, rowIndex, 'character', e.target.value)}
                              className="w-full text-[9px]"
                            />
                          </td>
                          {SIZE_RANGES.map((size) => (
                            <td key={size} className="border">
                              <input
                                type="text"
                                value={row.sizes[size]}
                                onChange={(e) => handleRowChange(currentIndex, rowIndex, `sizes.${size}`, e.target.value)}
                                className="w-full text-center text-[9px]"
                              />
                            </td>
                          ))}
                          <td className="border text-center font-bold text-[9px]">
                            {calculateRowTotal(row.sizes)}
                          </td>
                          <td className="border text-center no-print">
                            <button
                              onClick={() => removeRow(currentIndex, rowIndex)}
                              className="text-red-600 hover:text-red-800"
                              title="Remover linha"
                            >
                              <Trash2 size={12} />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr>
                        <td colSpan={3} className="border">
                          <button
                            onClick={() => addRow(currentIndex)}
                            className="flex items-center gap-1 text-[9px] text-blue-600 hover:text-blue-800 no-print px-0.5"
                          >
                            <Plus size={12} />
                            Adicionar linha
                          </button>
                        </td>
                        <td colSpan={SIZE_RANGES.length} className="border text-right font-bold text-[9px]">
                          Total:
                        </td>
                        <td className="border text-center font-bold text-[9px]">
                          {calculateSheetTotal(sheet.rows)}
                        </td>
                        <td className="border no-print"></td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              );
            })}
          </div>
        ))}
      </div>

      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #print-order-sheet, #print-order-sheet * {
            visibility: visible;
          }
          #print-order-sheet {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            padding: 0;
          }
          .no-print {
            display: none !important;
          }
          
          @page {
            size: A4;
            margin: 5mm;
          }

          .page {
            width: 200mm;
            height: 287mm;
            padding: 1mm;
            margin: 0 auto;
            page-break-after: always;
          }

          .order-sheet {
            height: 95mm;
            margin-bottom: 1mm;
            overflow: hidden;
          }

          .order-sheet:last-child {
            margin-bottom: 0;
          }

          input, select {
            border: none !important;
            padding: 0 !important;
          }

          th, td {
            padding: 0.25mm !important;
          }

          select {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            background: none;
          }
        }

        .page {
          width: 210mm;
          margin: 0 auto 5mm auto;
          padding: 5mm;
          box-shadow: 0 0 10px rgba(0,0,0,0.1);
          background: white;
        }

        .order-sheet {
          margin-bottom: 5mm;
        }

        .order-sheet:last-child {
          margin-bottom: 0;
        }

        input, select {
          border: 1px solid #e2e8f0;
          padding: 0px 1px;
          outline: none;
        }

        input:focus, select:focus {
          border-color: #4f46e5;
          ring: 1px;
          ring-color: #4f46e5;
        }

        table {
          border-spacing: 0;
        }

        th, td {
          padding: 0px;
        }
      `}</style>
    </div>
  );
}