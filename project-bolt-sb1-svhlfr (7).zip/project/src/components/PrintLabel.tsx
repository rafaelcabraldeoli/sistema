import React from 'react';
import { Box, Tag, User, MapPin } from 'lucide-react';
import type { Product } from '../types/Product';
import type { Customer } from '../types/Customer';

interface PrintLabelProps {
  product: Product;
  customer: Customer;
  volume: number;
  totalVolumes: number;
}

export default function PrintLabel({ product, customer, volume, totalVolumes }: PrintLabelProps) {
  // CSS for print media only - 100x60mm label size
  React.useEffect(() => {
    const style = document.createElement('style');
    style.innerHTML = `
      @media print {
        body * {
          visibility: hidden;
        }
        #print-labels, #print-labels * {
          visibility: visible;
        }
        #print-labels {
          position: absolute;
          left: 0;
          top: 0;
        }
        .label {
          width: 100mm;
          height: 60mm;
          padding: 5mm;
          page-break-after: always;
        }
        @page {
          size: 100mm 60mm;
          margin: 0;
        }
      }
    `;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);

  return (
    <div id="print-labels">
      <div className="label bg-white flex flex-col justify-between p-4">
        {/* Cliente e Endereço */}
        <div className="border-b pb-2">
          <div className="flex items-center gap-2 mb-1">
            <User size={14} className="text-gray-600" />
            <h3 className="font-bold text-sm truncate">{customer.name}</h3>
          </div>
          <div className="flex items-start gap-2">
            <MapPin size={14} className="text-gray-600 mt-1 flex-shrink-0" />
            <p className="text-xs text-gray-600 break-words">{customer.address}</p>
          </div>
        </div>

        {/* Produto e Volume */}
        <div className="flex-1 flex flex-col justify-center py-2">
          <div className="text-center space-y-2">
            <h2 className="text-lg font-bold">{product.name}</h2>
            <p className="text-sm text-gray-600">{product.category}</p>
            <div className="flex items-center justify-center gap-2">
              <Box className="w-4 h-4 text-gray-600" />
              <p className="text-sm">Volume {volume} de {totalVolumes}</p>
            </div>
          </div>
        </div>

        {/* Código e Preço */}
        <div className="border-t pt-2 flex items-center justify-between">
          <div className="text-xs text-gray-500">
            Cód: {product.id.slice(0, 8)}
          </div>
          <div className="text-lg font-bold">
            R$ {product.price.toFixed(2)}
          </div>
        </div>
      </div>
    </div>
  );
}