import React from 'react';
import { Calendar, User, Box, FileText, Printer, Tag, CheckCircle, XCircle, Trash2 } from 'lucide-react';
import type { Order } from '../types/Order';
import type { Customer } from '../types/Customer';
import type { Product } from '../types/Product';
import PrintOrder from './PrintOrder';
import PrintLabels from './PrintLabels';
import { formatCurrency, getStatusText, getStatusColor } from '../utils/formatters';

interface OrdersListProps {
  orders: Order[];
  customers: Customer[];
  products: Product[];
  onUpdateStatus: (orderId: string, status: Order['status']) => void;
  onDeleteOrder: (orderId: string) => void;
  onSelectOrder: (orderId: string | null) => void;
}

export default function OrdersList({ 
  orders, 
  customers, 
  products, 
  onUpdateStatus, 
  onDeleteOrder,
  onSelectOrder 
}: OrdersListProps) {
  const [printingOrder, setPrintingOrder] = React.useState<Order | null>(null);
  const [printingLabels, setPrintingLabels] = React.useState<Array<{
    product: Product;
    customer: Customer;
    quantity: number;
    volume: number;
    totalVolumes: number;
  }> | null>(null);

  const getCustomer = (customerId: string): Customer | undefined => {
    return customers.find(c => c.id === customerId);
  };

  const getProduct = (productId: string): Product | undefined => {
    return products.find(p => p.id === productId);
  };

  const getProductName = (productId: string): string => {
    return getProduct(productId)?.name || 'Produto não encontrado';
  };

  const handleDeleteOrder = (orderId: string) => {
    const order = orders.find(o => o.id === orderId);
    if (!order || order.status === 'completed') {
      alert('Pedidos confirmados não podem ser excluídos.');
      return;
    }
    
    if (window.confirm('Tem certeza que deseja excluir este pedido?')) {
      onDeleteOrder(orderId);
    }
  };

  const handlePrintOrder = (order: Order) => {
    setPrintingOrder(order);
    setTimeout(() => {
      window.print();
      setPrintingOrder(null);
    }, 100);
  };

  const handlePrintLabels = (order: Order) => {
    const customer = getCustomer(order.customerId);
    if (!customer || !order.items) return;
    
    const totalVolumes = order.items.reduce((sum, item) => sum + item.quantity, 0);
    const labels: Array<{
      product: Product;
      customer: Customer;
      quantity: number;
      volume: number;
      totalVolumes: number;
    }> = [];

    let currentVolume = 1;

    order.items.forEach((item) => {
      const product = getProduct(item.productId);
      if (product) {
        for (let i = 0; i < item.quantity; i++) {
          labels.push({
            product,
            customer,
            quantity: item.quantity,
            volume: currentVolume,
            totalVolumes,
          });
          currentVolume++;
        }
      }
    });

    setPrintingLabels(labels);
    setTimeout(() => {
      window.print();
      setPrintingLabels(null);
    }, 100);
  };

  if (printingOrder) {
    const customer = getCustomer(printingOrder.customerId);
    if (!customer) return null;
    return <PrintOrder order={printingOrder} customer={customer} products={products} />;
  }

  if (printingLabels) {
    return <PrintLabels labels={printingLabels} />;
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {orders.map((order) => {
        const customer = getCustomer(order.customerId);
        if (!customer) return null;

        return (
          <div key={order.id} className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-800">
                  Pedido #{order.id.slice(0, 8)}
                </h3>
                <div className="flex items-center gap-2">
                  <span className={`px-3 py-1 rounded-full text-sm ${getStatusColor(order.status)}`}>
                    {getStatusText(order.status)}
                  </span>
                  {order.status !== 'completed' && (
                    <button
                      onClick={() => handleDeleteOrder(order.id)}
                      className="p-1 text-red-600 hover:text-red-800 transition-colors"
                      title="Excluir Pedido"
                    >
                      <Trash2 size={18} />
                    </button>
                  )}
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-2 text-gray-600">
                  <User size={16} className="text-blue-500" />
                  <span>{customer.name}</span>
                </div>

                <div className="flex items-center gap-2 text-gray-600">
                  <Calendar size={16} className="text-purple-500" />
                  <span>{new Date(order.date).toLocaleString()}</span>
                </div>

                {order.notes && (
                  <div className="flex items-start gap-2 text-gray-600">
                    <FileText size={16} className="text-gray-500 mt-1" />
                    <span>{order.notes}</span>
                  </div>
                )}
              </div>

              <div className="mt-4 space-y-2">
                <h4 className="font-medium text-gray-700">Itens</h4>
                {order.items.map((item, index) => (
                  <div key={index} className="flex justify-between text-sm bg-gray-50 p-2 rounded">
                    <span>{getProductName(item.productId)}</span>
                    <span>
                      {item.quantity} x {formatCurrency(item.price)}
                    </span>
                  </div>
                ))}
                <div className="text-right font-bold pt-2">
                  Total: {formatCurrency(order.total)}
                </div>
              </div>

              <div className="flex flex-col gap-2 pt-4 border-t">
                <div className="flex gap-2">
                  <button
                    onClick={() => handlePrintOrder(order)}
                    className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex-1"
                  >
                    <Printer size={16} />
                    Imprimir Pedido
                  </button>
                  <button
                    onClick={() => handlePrintLabels(order)}
                    className="flex items-center gap-2 px-3 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 flex-1"
                  >
                    <Tag size={16} />
                    Imprimir Etiquetas
                  </button>
                </div>

                {order.status === 'pending' && (
                  <div className="flex gap-2">
                    <button
                      onClick={() => onUpdateStatus(order.id, 'processing')}
                      className="flex items-center gap-2 px-3 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700 flex-1"
                    >
                      <Box size={16} />
                      Pagamento Confirmado
                    </button>
                  </div>
                )}

                {order.status === 'processing' && (
                  <div className="flex gap-2">
                    <button
                      onClick={() => onUpdateStatus(order.id, 'completed')}
                      className="flex items-center gap-2 px-3 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 flex-1"
                    >
                      <CheckCircle size={16} />
                      Concluir Pedido
                    </button>
                    <button
                      onClick={() => onUpdateStatus(order.id, 'cancelled')}
                      className="flex items-center gap-2 px-3 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 flex-1"
                    >
                      <XCircle size={16} />
                      Cancelar Pedido
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}