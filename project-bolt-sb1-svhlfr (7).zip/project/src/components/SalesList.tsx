import React from 'react';
import { Calendar, User, CreditCard, FileText, Printer, Tag } from 'lucide-react';
import type { Sale } from '../types/Sale';
import type { Customer } from '../types/Customer';
import type { Product } from '../types/Product';
import PrintOrder from './PrintOrder';
import PrintLabel from './PrintLabel';

interface SalesListProps {
  sales: Sale[];
  customers: Customer[];
  products: Product[];
}

export default function SalesList({ sales, customers, products }: SalesListProps) {
  const [printingSale, setPrintingSale] = React.useState<Sale | null>(null);
  const [printingLabel, setPrintingLabel] = React.useState<{
    product: Product;
    customer: Customer;
    quantity: number;
    volume: number;
    totalVolumes: number;
  } | null>(null);

  if (sales.length === 0) {
    return (
      <div className="text-center py-12 bg-white rounded-xl shadow-lg">
        <p className="text-gray-500">Nenhuma venda registrada</p>
      </div>
    );
  }

  const getCustomer = (customerId: string) => {
    return customers.find(c => c.id === customerId);
  };

  const getProduct = (productId: string) => {
    return products.find(p => p.id === productId);
  };

  const getProductName = (productId: string) => {
    return getProduct(productId)?.name || 'Produto Desconhecido';
  };

  const getStatusColor = (status: Sale['status']) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
    }
  };

  const getStatusText = (status: Sale['status']) => {
    switch (status) {
      case 'completed':
        return 'Concluída';
      case 'pending':
        return 'Pendente';
      case 'cancelled':
        return 'Cancelada';
    }
  };

  const getPaymentMethodText = (method: string) => {
    switch (method) {
      case 'cash':
        return 'Dinheiro';
      case 'credit':
        return 'Cartão de Crédito';
      case 'debit':
        return 'Cartão de Débito';
      case 'transfer':
        return 'Transferência Bancária';
      default:
        return method;
    }
  };

  const handlePrintOrder = (sale: Sale) => {
    setPrintingSale(sale);
    setTimeout(() => {
      window.print();
      setPrintingSale(null);
    }, 100);
  };

  const handlePrintLabels = (sale: Sale) => {
    const customer = getCustomer(sale.customerId);
    if (!customer) return;

    const totalVolumes = sale.items.reduce((sum, item) => sum + item.quantity, 0);
    let currentVolume = 1;

    sale.items.forEach((item) => {
      const product = getProduct(item.productId);
      if (product) {
        for (let i = 0; i < item.quantity; i++) {
          setPrintingLabel({
            product,
            customer,
            quantity: item.quantity,
            volume: currentVolume,
            totalVolumes,
          });
          setTimeout(() => {
            window.print();
            if (currentVolume === totalVolumes) {
              setPrintingLabel(null);
            }
          }, 100);
          currentVolume++;
        }
      }
    });
  };

  if (printingSale) {
    const customer = getCustomer(printingSale.customerId);
    if (!customer) return null;
    return <PrintOrder sale={printingSale} customer={customer} products={products} />;
  }

  if (printingLabel) {
    return <PrintLabel {...printingLabel} />;
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {sales.map((sale) => (
        <div key={sale.id} className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-800">
                Venda #{sale.id.slice(0, 8)}
              </h3>
              <span className={`px-3 py-1 rounded-full text-sm ${getStatusColor(sale.status)}`}>
                {getStatusText(sale.status)}
              </span>
            </div>

            <div className="space-y-3">
              <div className="flex items-center gap-2 text-gray-600">
                <User size={16} className="text-blue-500" />
                <span>{getCustomer(sale.customerId)?.name}</span>
              </div>

              <div className="flex items-center gap-2 text-gray-600">
                <Calendar size={16} className="text-purple-500" />
                <span>{new Date(sale.date).toLocaleString()}</span>
              </div>

              <div className="flex items-center gap-2 text-gray-600">
                <CreditCard size={16} className="text-green-500" />
                <span>{getPaymentMethodText(sale.paymentMethod)}</span>
              </div>

              {sale.notes && (
                <div className="flex items-start gap-2 text-gray-600">
                  <FileText size={16} className="text-gray-500 mt-1" />
                  <span>{sale.notes}</span>
                </div>
              )}
            </div>

            <div className="mt-4 space-y-2">
              <h4 className="font-medium text-gray-700">Itens</h4>
              {sale.items.map((item, index) => (
                <div key={index} className="flex justify-between text-sm bg-gray-50 p-2 rounded">
                  <span>{getProductName(item.productId)}</span>
                  <span>
                    {item.quantity} x R$ {item.priceAtSale.toFixed(2)}
                  </span>
                </div>
              ))}
              <div className="text-right font-bold pt-2">
                Total: R$ {sale.total.toFixed(2)}
              </div>
            </div>

            <div className="flex gap-2 pt-4 border-t">
              <button
                onClick={() => handlePrintOrder(sale)}
                className="flex items-center gap-2 px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 flex-1"
              >
                <Printer size={16} />
                Imprimir Pedido
              </button>
              <button
                onClick={() => handlePrintLabels(sale)}
                className="flex items-center gap-2 px-3 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 flex-1"
              >
                <Tag size={16} />
                Imprimir Etiquetas
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}