import React, { useState, useEffect } from 'react';
import { Printer, List } from 'lucide-react';
import { db } from '../services/db';
import type { OrderSheet } from '../types/OrderSheet';

interface SolaSummary {
  sole: string;
  color: string;
  sizes: { [key: string]: number };
}

export default function PedidoSola() {
  const [orderSheets, setOrderSheets] = useState<OrderSheet[]>([]);
  const [solaSummaries, setSolaSummaries] = useState<SolaSummary[]>([]);
  const [dateFilter, setDateFilter] = useState(new Date().toISOString().split('T')[0]);

  useEffect(() => {
    loadOrderSheets();
  }, []);

  const loadOrderSheets = async () => {
    const sheets = await db.getAllOrderSheets();
    setOrderSheets(sheets.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
  };

  useEffect(() => {
    const summaries: { [key: string]: SolaSummary } = {};

    orderSheets.forEach(sheet => {
      if (new Date(sheet.orderDate).toISOString().split('T')[0] === dateFilter) {
        sheet.rows.forEach(row => {
          if (row.sole && row.soleColor) {
            const key = `${row.sole}-${row.soleColor}`;
            
            if (!summaries[key]) {
              summaries[key] = {
                sole: row.sole,
                color: row.soleColor,
                sizes: {}
              };
            }

            Object.entries(row.sizes).forEach(([size, quantity]) => {
              if (quantity) {
                const qty = parseInt(quantity) || 0;
                summaries[key].sizes[size] = (summaries[key].sizes[size] || 0) + qty;
              }
            });
          }
        });
      }
    });

    setSolaSummaries(Object.values(summaries));
  }, [orderSheets, dateFilter]);

  const calculateTotal = (sizes: { [key: string]: number }): number => {
    return Object.values(sizes).reduce((sum, qty) => sum + qty, 0);
  };

  const calculateGrandTotal = (): number => {
    return solaSummaries.reduce((sum, summary) => sum + calculateTotal(summary.sizes), 0);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">Pedido de Sola</h2>
        <div className="flex items-center gap-4">
          <input
            type="date"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            className="px-3 py-2 border rounded-md"
          />
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 no-print"
          >
            <Printer size={20} />
            Imprimir
          </button>
        </div>
      </div>

      <div id="print-sola" className="bg-white rounded-lg shadow-lg p-6">
        <div className="space-y-8">
          {solaSummaries.map((summary, index) => (
            <div key={index} className="border-b pb-6 last:border-b-0">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h3 className="text-xl font-bold">{summary.sole}</h3>
                  <p className="text-gray-600">Cor: {summary.color}</p>
                </div>
                <p className="text-lg font-bold">
                  Total: {calculateTotal(summary.sizes)} pares
                </p>
              </div>

              <div className="grid grid-cols-4 sm:grid-cols-7 gap-4">
                {Object.entries(summary.sizes)
                  .sort(([a], [b]) => {
                    const [aStart] = a.split('/').map(Number);
                    const [bStart] = b.split('/').map(Number);
                    return aStart - bStart;
                  })
                  .map(([size, quantity]) => (
                    <div key={size} className="bg-gray-50 p-3 rounded-lg text-center">
                      <p className="font-medium text-gray-600">{size}</p>
                      <p className="text-xl font-bold">{quantity}</p>
                    </div>
                  ))}
              </div>
            </div>
          ))}

          {solaSummaries.length > 0 && (
            <div className="border-t pt-6 mt-6">
              <div className="flex justify-between items-center">
                <h3 className="text-2xl font-bold text-gray-800">Total Geral</h3>
                <p className="text-2xl font-bold text-blue-600">
                  {calculateGrandTotal()} pares
                </p>
              </div>
            </div>
          )}

          {solaSummaries.length === 0 && (
            <p className="text-center text-gray-500 py-8">
              Nenhum pedido de sola encontrado para esta data
            </p>
          )}
        </div>
      </div>

      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          #print-sola, #print-sola * {
            visibility: visible;
          }
          #print-sola {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
          }
        }
      `}</style>
    </div>
  );
}