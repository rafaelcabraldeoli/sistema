import React from 'react';

interface MenuProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export default function Menu({ activeTab, onTabChange }: MenuProps) {
  const menuItems = [
    { id: 'orderSheet', label: 'FICHA\nPEDIDOS' },
    { id: 'labels', label: 'ETIQUETAS' },
    { id: 'uniatria', label: 'UNITARIA' },
    { id: 'products', label: 'PRODUTOS' },
    { id: 'sales', label: 'VENDAS' },
    { id: 'orders', label: 'PEDIDOS' },
    { id: 'customers', label: 'CLIENTES' },
    { id: 'pedidoSola', label: 'PEDIDO\nSOLA' },
    { id: 'balance', label: 'BALANÇO' },
  ];

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-5xl font-bold text-center mb-12 p-8 bg-white rounded-2xl shadow-lg">
          SISTEMA DE PEDIDOS
        </h1>
        
        <div className="grid grid-cols-3 gap-6">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`
                aspect-[4/3]
                flex items-center justify-center
                text-2xl font-bold
                bg-white hover:bg-gray-50
                rounded-2xl shadow-lg hover:shadow-xl
                transition-all duration-200
                p-6
                whitespace-pre-line
                ${activeTab === item.id ? 'ring-4 ring-blue-500' : ''}
              `}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}