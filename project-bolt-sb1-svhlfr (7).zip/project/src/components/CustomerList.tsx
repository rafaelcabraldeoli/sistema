import React from 'react';
import { Phone, MapPin, Calendar, ShoppingBag } from 'lucide-react';
import type { Customer } from '../types/Customer';

interface CustomerListProps {
  customers: Customer[];
}

export default function CustomerList({ customers }: CustomerListProps) {
  if (customers.length === 0) {
    return (
      <div className="text-center py-12 bg-white rounded-xl shadow-lg">
        <p className="text-gray-500">Nenhum cliente cadastrado</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {customers.map((customer) => (
        <div key={customer.id} className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-6 space-y-4">
            <h3 className="text-xl font-semibold text-gray-800">{customer.name}</h3>
            
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-gray-600">
                <Phone size={16} className="text-green-500" />
                <a href={`tel:${customer.phone}`} className="hover:text-blue-600">
                  {customer.phone}
                </a>
              </div>
              
              <div className="flex items-start gap-2 text-gray-600">
                <MapPin size={16} className="text-red-500 mt-1 flex-shrink-0" />
                <span>{customer.address}</span>
              </div>
              
              <div className="flex items-center gap-2 text-gray-600">
                <Calendar size={16} className="text-purple-500" />
                <span>Cadastrado em: {new Date(customer.createdAt).toLocaleDateString()}</span>
              </div>
              
              {customer.lastPurchase && (
                <div className="flex items-center gap-2 text-gray-600">
                  <ShoppingBag size={16} className="text-amber-500" />
                  <span>Última Compra: {new Date(customer.lastPurchase).toLocaleDateString()}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}