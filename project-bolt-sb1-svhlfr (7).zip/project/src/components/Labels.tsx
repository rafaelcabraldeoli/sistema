import React, { useState, useEffect } from 'react';
import { Printer, List, X, ArrowLeft } from 'lucide-react';
import type { OrderSheet } from '../types/OrderSheet';
import { db } from '../services/db';

interface Label {
  category: string;
  type: 'baby' | 'juvenil';
  character: string;
  sizes: Array<{
    start: string;
    end: string;
    qty: number;
  }>;
}

const BABY_SIZES = ['20/21', '22/23', '24/25'];
const JUVENIL_SIZES = ['26/27', '28/29', '30/31', '32/33'];
const BABY_DISTRIBUTION = {
  '20/21': 2,
  '22/23': 5,
  '24/25': 5
};
const JUVENIL_DISTRIBUTION = {
  '26/27': 3,
  '28/29': 3,
  '30/31': 3,
  '32/33': 3
};

export default function Labels() {
  const [labels, setLabels] = useState<Label[]>([]);
  const [savedSheets, setSavedSheets] = useState<OrderSheet[]>([]);
  const [showSavedSheets, setShowSavedSheets] = useState(false);

  useEffect(() => {
    loadSavedSheets();
  }, []);

  const loadSavedSheets = async () => {
    const sheets = await db.getAllOrderSheets();
    setSavedSheets(sheets.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
  };

  const generateBabyLabels = (
    character: string,
    category: string,
    sizes: Record<string, number>
  ): Label[] => {
    const labels: Label[] = [];
    const remainingPairs = { ...sizes };
    
    while (Object.values(remainingPairs).some(qty => qty > 0)) {
      const labelSizes: Array<{ start: string; end: string; qty: number }> = [];
      
      Object.entries(BABY_DISTRIBUTION).forEach(([size, targetQty]) => {
        const available = remainingPairs[size] || 0;
        const qty = Math.min(available, targetQty);
        if (qty > 0) {
          const [start, end] = size.split('/');
          labelSizes.push({ start, end, qty });
          remainingPairs[size] = available - qty;
        }
      });

      if (labelSizes.length > 0) {
        labels.push({
          category,
          type: 'baby',
          character: character.toUpperCase(),
          sizes: labelSizes
        });
      }
    }

    return labels;
  };

  const generateJuvenilLabels = (
    character: string,
    category: string,
    sizes: Record<string, number>
  ): Label[] => {
    const labels: Label[] = [];
    const remainingPairs = { ...sizes };
    const totalPairs = Object.values(sizes).reduce((sum, qty) => sum + qty, 0);
    const numLabels = Math.ceil(totalPairs / 12);

    for (let i = 0; i < numLabels; i++) {
      const labelSizes: Array<{ start: string; end: string; qty: number }> = [];
      let pairsInLabel = 0;

      Object.entries(JUVENIL_DISTRIBUTION).forEach(([size, targetQty]) => {
        const available = remainingPairs[size] || 0;
        if (available > 0) {
          const qty = Math.min(available, targetQty);
          const [start, end] = size.split('/');
          labelSizes.push({ start, end, qty });
          remainingPairs[size] = available - qty;
          pairsInLabel += qty;
        }
      });

      if (pairsInLabel < 12) {
        const availableSizes = Object.entries(remainingPairs)
          .filter(([_, qty]) => qty > 0)
          .map(([size]) => size);

        for (const size of availableSizes) {
          const spaceLeft = 12 - pairsInLabel;
          if (spaceLeft <= 0) break;

          const available = remainingPairs[size];
          const qty = Math.min(available, spaceLeft);
          if (qty > 0) {
            const [start, end] = size.split('/');
            const existingSize = labelSizes.find(s => s.start === start && s.end === end);
            if (existingSize) {
              existingSize.qty += qty;
            } else {
              labelSizes.push({ start, end, qty });
            }
            remainingPairs[size] = available - qty;
            pairsInLabel += qty;
          }
        }
      }

      if (labelSizes.length > 0) {
        labels.push({
          category,
          type: 'juvenil',
          character: character.toUpperCase(),
          sizes: labelSizes
        });
      }
    }

    return labels;
  };

  const generateLabels = (sheet: OrderSheet) => {
    const allLabels: Label[] = [];
    
    sheet.rows.forEach(row => {
      if (!row.character) return;

      const sizeEntries = Object.entries(row.sizes)
        .filter(([_, qty]) => parseInt(qty) > 0)
        .map(([size, qty]) => [size, parseInt(qty)] as [string, number]);

      if (sizeEntries.length === 0) return;

      const babySizes = Object.fromEntries(
        sizeEntries.filter(([size]) => BABY_SIZES.includes(size))
      );
      
      const juvenilSizes = Object.fromEntries(
        sizeEntries.filter(([size]) => JUVENIL_SIZES.includes(size))
      );

      if (Object.keys(babySizes).length > 0) {
        const babyLabels = generateBabyLabels(row.character, sheet.category, babySizes);
        allLabels.push(...babyLabels);
      }

      if (Object.keys(juvenilSizes).length > 0) {
        const juvenilLabels = generateJuvenilLabels(row.character, sheet.category, juvenilSizes);
        allLabels.push(...juvenilLabels);
      }
    });

    setLabels(allLabels);
    setShowSavedSheets(false);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">Impressão de Etiquetas</h2>
        <div className="flex gap-4">
          <button
            onClick={() => setShowSavedSheets(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 no-print"
          >
            <List size={20} />
            Selecionar Ficha
          </button>
          {labels.length > 0 && (
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 no-print"
            >
              <Printer size={20} />
              Imprimir Etiquetas ({labels.length})
            </button>
          )}
        </div>
      </div>

      {showSavedSheets && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full max-h-[80vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold">Selecione uma Ficha</h3>
              <div className="flex gap-2">
                <button
                  onClick={() => setShowSavedSheets(false)}
                  className="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700"
                >
                  <ArrowLeft size={20} />
                  Voltar
                </button>
                <button
                  onClick={() => setShowSavedSheets(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X size={24} />
                </button>
              </div>
            </div>
            <div className="space-y-4">
              {savedSheets.map((sheet) => (
                <div key={sheet.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-semibold">{sheet.client}</p>
                    <p className="text-sm text-gray-500">
                      Pedido #{sheet.orderNumber} • {new Date(sheet.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <button
                    onClick={() => generateLabels(sheet)}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                  >
                    Gerar Etiquetas
                  </button>
                </div>
              ))}
              {savedSheets.length === 0 && (
                <p className="text-center text-gray-500">Nenhuma ficha salva</p>
              )}
            </div>
          </div>
        </div>
      )}

      <div id="print-labels">
        {labels.map((label, index) => (
          <div key={index} className="label">
            <div className="label-content">
              <div className="header">
                <span className="category">{label.category}</span>
                <span className="type">{label.type.toUpperCase()}</span>
              </div>
              <div className="character">{label.character}</div>
              <div className="pairs">12 PARES</div>
              <div className="sizes-grid">
                {label.sizes.map((size, idx) => (
                  <div key={idx} className="size-box">
                    <div className="size-range">{size.start}/{size.end}</div>
                    <div className="size-qty">{size.qty}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      <style>{`
        @page {
          size: 100mm 60mm;
          margin: 0;
        }

        @media print {
          body * {
            visibility: hidden;
          }

          #print-labels, #print-labels * {
            visibility: visible;
          }

          #print-labels {
            position: absolute;
            left: 0;
            top: 0;
            width: 100mm;
            margin: 0;
            padding: 0;
          }

          .label {
            page-break-after: always;
            page-break-inside: avoid;
            width: 100mm;
            height: 60mm;
            margin: 0;
            padding: 0;
          }

          .label:last-child {
            page-break-after: auto;
          }
        }

        .label {
          width: 100mm;
          height: 60mm;
          padding: 3mm;
          box-sizing: border-box;
          position: relative;
          background: white;
          margin: 0 auto 2mm;
        }

        .label-content {
          height: 100%;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
        }

        .header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1mm;
        }

        .category, .type {
          font-family: 'Arial Black', Arial, sans-serif;
          font-size: 14pt;
          font-weight: 900;
          text-transform: uppercase;
        }

        .character {
          font-family: 'Arial Black', Arial, sans-serif;
          font-size: 36pt;
          font-weight: 900;
          text-align: center;
          line-height: 1;
          margin: 2mm 0;
          text-transform: uppercase;
        }

        .pairs {
          font-family: 'Arial Black', Arial, sans-serif;
          font-size: 14pt;
          font-weight: 900;
          text-align: center;
          margin: 1mm 0;
        }

        .sizes-grid {
          display: flex;
          justify-content: space-between;
          gap: 1mm;
          margin-top: 1mm;
        }

        .size-box {
          flex: 1;
          border: 1px solid black;
          display: flex;
          flex-direction: column;
        }

        .size-range {
          font-family: 'Arial Black', Arial, sans-serif;
          font-size: 10pt;
          font-weight: 900;
          text-align: center;
          padding: 0.5mm;
          border-bottom: 1px solid black;
        }

        .size-qty {
          font-family: 'Arial Black', Arial, sans-serif;
          font-size: 16pt;
          font-weight: 900;
          text-align: center;
          padding: 1mm;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        @media screen {
          #print-labels {
            width: 100mm;
            margin: 0 auto;
          }
        }
      `}</style>
    </div>
  );
}