import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Plus, Minus, Printer } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  quantity: number;
  image: string;
}

interface StockHistory {
  id: string;
  productId: string;
  type: 'add' | 'remove';
  quantity: number;
  date: string;
  notes?: string;
}

interface ProductListProps {
  products: Product[];
  stockHistory: StockHistory[];
  onUpdateStock: (productId: string, quantity: number, type: 'add' | 'remove') => void;
  onAddHistory: (history: Omit<StockHistory, 'id'>) => void;
}

export default function ProductList({ products, stockHistory, onUpdateStock, onAddHistory }: ProductListProps) {
  const [expandedProducts, setExpandedProducts] = useState<Set<string>>(new Set());
  const [stockAdjustment, setStockAdjustment] = useState<{ [key: string]: number }>({});
  const [notes, setNotes] = useState<{ [key: string]: string }>({});

  const toggleExpand = (productId: string) => {
    const newExpanded = new Set(expandedProducts);
    if (newExpanded.has(productId)) {
      newExpanded.delete(productId);
    } else {
      newExpanded.add(productId);
    }
    setExpandedProducts(newExpanded);
  };

  const handleStockAdjustment = (productId: string, type: 'add' | 'remove') => {
    const quantity = stockAdjustment[productId] || 0;
    if (quantity <= 0) return;

    onUpdateStock(productId, quantity, type);
    onAddHistory({
      productId,
      type,
      quantity,
      date: new Date().toISOString(),
      notes: notes[productId],
    });

    setStockAdjustment(prev => ({ ...prev, [productId]: 0 }));
    setNotes(prev => ({ ...prev, [productId]: '' }));
  };

  const printLabel = (product: Product) => {
    const labelContent = `
      <div style="width: 100mm; height: 60mm; padding: 5mm; font-family: Arial;">
        <div style="text-align: center; font-size: 14pt; font-weight: bold;">
          ${product.name}
        </div>
        <div style="text-align: center; font-size: 12pt; margin-top: 5mm;">
          Preço: R$ ${product.price.toFixed(2)}
        </div>
        <div style="text-align: center; font-size: 10pt; margin-top: 3mm;">
          Categoria: ${product.category}
        </div>
      </div>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Etiqueta - ${product.name}</title>
            <style>
              @media print {
                @page {
                  size: 100mm 60mm;
                  margin: 0;
                }
                body {
                  margin: 0;
                }
              }
            </style>
          </head>
          <body>${labelContent}</body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
  };

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-gray-800">Lista de Produtos</h2>
      <div className="grid gap-4">
        {products.map(product => (
          <div
            key={product.id}
            className="bg-white rounded-lg shadow-md overflow-hidden"
          >
            <div className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-16 h-16 object-cover rounded-lg"
                  />
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800">{product.name}</h3>
                    <p className="text-gray-600">R$ {product.price.toFixed(2)}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <p className="text-sm text-gray-600">Em estoque</p>
                    <p className="font-semibold text-gray-800">
                      {product.quantity} unidades
                    </p>
                  </div>
                  <button
                    onClick={() => toggleExpand(product.id)}
                    className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                  >
                    {expandedProducts.has(product.id) ? (
                      <ChevronUp className="w-5 h-5" />
                    ) : (
                      <ChevronDown className="w-5 h-5" />
                    )}
                  </button>
                </div>
              </div>

              {expandedProducts.has(product.id) && (
                <div className="mt-4 border-t pt-4 space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <h4 className="font-semibold text-gray-700">Ajuste de Estoque</h4>
                      <div className="flex items-center space-x-2">
                        <input
                          type="number"
                          min="0"
                          value={stockAdjustment[product.id] || 0}
                          onChange={(e) => setStockAdjustment(prev => ({
                            ...prev,
                            [product.id]: parseInt(e.target.value) || 0
                          }))}
                          className="w-20 px-2 py-1 border rounded-md"
                        />
                        <button
                          onClick={() => handleStockAdjustment(product.id, 'add')}
                          className="p-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleStockAdjustment(product.id, 'remove')}
                          className="p-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                      </div>
                      <input
                        type="text"
                        placeholder="Observações"
                        value={notes[product.id] || ''}
                        onChange={(e) => setNotes(prev => ({
                          ...prev,
                          [product.id]: e.target.value
                        }))}
                        className="w-full px-2 py-1 border rounded-md"
                      />
                    </div>
                    <div className="space-y-2">
                      <h4 className="font-semibold text-gray-700">Histórico</h4>
                      <div className="max-h-40 overflow-y-auto space-y-2">
                        {stockHistory
                          .filter(history => history.productId === product.id)
                          .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                          .map(history => (
                            <div
                              key={history.id}
                              className="text-sm text-gray-600 border-l-4 pl-2"
                              style={{
                                borderColor: history.type === 'add' ? '#059669' : '#DC2626'
                              }}
                            >
                              <p className="font-semibold">
                                {history.type === 'add' ? 'Entrada' : 'Saída'}: {history.quantity} unidades
                              </p>
                              <p className="text-xs">
                                {new Date(history.date).toLocaleString()}
                              </p>
                              {history.notes && (
                                <p className="text-xs italic">{history.notes}</p>
                              )}
                            </div>
                          ))}
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-end">
                    <button
                      onClick={() => printLabel(product)}
                      className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                    >
                      <Printer className="w-4 h-4" />
                      <span>Imprimir Etiqueta</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}