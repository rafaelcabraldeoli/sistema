import { openDB, DBSchema, IDBPDatabase } from 'idb';
import type { Product } from '../types/Product';
import type { Customer } from '../types/Customer';
import type { Sale } from '../types/Sale';
import type { Order } from '../types/Order';
import type { StockHistory } from '../types/Product';
import type { OrderSheet } from '../types/OrderSheet';

interface AppDB extends DBSchema {
  products: {
    key: string;
    value: Product;
  };
  customers: {
    key: string;
    value: Customer;
  };
  sales: {
    key: string;
    value: Sale;
  };
  orders: {
    key: string;
    value: Order;
  };
  stockHistory: {
    key: string;
    value: StockHistory;
  };
  orderSheets: {
    key: string;
    value: OrderSheet;
  };
}

class DatabaseService {
  private db: Promise<IDBPDatabase<AppDB>>;

  constructor() {
    this.db = openDB<AppDB>('empresa-db', 8, {
      upgrade(db, oldVersion, newVersion) {
        // Create stores if they don't exist
        if (!db.objectStoreNames.contains('products')) {
          db.createObjectStore('products', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('customers')) {
          db.createObjectStore('customers', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('sales')) {
          db.createObjectStore('sales', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('orders')) {
          db.createObjectStore('orders', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('stockHistory')) {
          db.createObjectStore('stockHistory', { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('orderSheets')) {
          db.createObjectStore('orderSheets', { keyPath: 'id' });
        }
      },
    });
  }

  async getAllProducts(): Promise<Product[]> {
    return (await this.db).getAll('products');
  }

  async addProduct(product: Product): Promise<void> {
    return (await this.db).add('products', product);
  }

  async updateProduct(product: Product): Promise<void> {
    return (await this.db).put('products', product);
  }

  async deleteProduct(id: string): Promise<void> {
    return (await this.db).delete('products', id);
  }

  async getAllCustomers(): Promise<Customer[]> {
    return (await this.db).getAll('customers');
  }

  async addCustomer(customer: Customer): Promise<void> {
    return (await this.db).add('customers', customer);
  }

  async updateCustomer(customer: Customer): Promise<void> {
    return (await this.db).put('customers', customer);
  }

  async deleteCustomer(id: string): Promise<void> {
    return (await this.db).delete('customers', id);
  }

  async getAllSales(): Promise<Sale[]> {
    return (await this.db).getAll('sales');
  }

  async addSale(sale: Sale): Promise<void> {
    return (await this.db).add('sales', sale);
  }

  async updateSale(sale: Sale): Promise<void> {
    return (await this.db).put('sales', sale);
  }

  async deleteSale(id: string): Promise<void> {
    return (await this.db).delete('sales', id);
  }

  async getAllOrders(): Promise<Order[]> {
    return (await this.db).getAll('orders');
  }

  async addOrder(order: Order): Promise<void> {
    return (await this.db).add('orders', order);
  }

  async updateOrder(order: Order): Promise<void> {
    return (await this.db).put('orders', order);
  }

  async deleteOrder(id: string): Promise<void> {
    return (await this.db).delete('orders', id);
  }

  async getAllStockHistory(): Promise<StockHistory[]> {
    return (await this.db).getAll('stockHistory');
  }

  async addStockHistory(history: StockHistory): Promise<void> {
    return (await this.db).add('stockHistory', history);
  }

  async getAllOrderSheets(): Promise<OrderSheet[]> {
    return (await this.db).getAll('orderSheets');
  }

  async addOrderSheet(sheet: OrderSheet): Promise<void> {
    return (await this.db).add('orderSheets', sheet);
  }

  async updateOrderSheet(sheet: OrderSheet): Promise<void> {
    return (await this.db).put('orderSheets', sheet);
  }

  async deleteOrderSheet(id: string): Promise<void> {
    return (await this.db).delete('orderSheets', id);
  }
}

export const db = new DatabaseService();