const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electron', {
  print: () => ipcRenderer.invoke('print-request'),
  onPrintResponse: (callback) => ipcRenderer.on('print-response', callback),
});