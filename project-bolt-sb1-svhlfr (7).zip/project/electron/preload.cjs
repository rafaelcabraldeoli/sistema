const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electron', {
  print: () => ipcRenderer.invoke('print'),
  platform: process.platform,
  isDev: process.env.NODE_ENV === 'development',
  versions: {
    node: () => process.versions.node,
    chrome: () => process.versions.chrome,
    electron: () => process.versions.electron
  },
  appInfo: {
    name: require('../package.json').productName,
    version: require('../package.json').version
  }
});